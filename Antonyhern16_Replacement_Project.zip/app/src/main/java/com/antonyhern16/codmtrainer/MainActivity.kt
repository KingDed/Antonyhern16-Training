package com.antonyhern16.codmtrainer

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("trainer_settings", Context.MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(13, 18, 30)
        window.navigationBarColor = Color.rgb(13, 18, 30)
        buildUi()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            setBackgroundColor(Color.rgb(13, 18, 30))
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        addText("ANTONYHERN16", 26, Color.WHITE, true)
        addText("CODM TRAINING CONTROL CENTER", 14, Color.rgb(90, 200, 255), true)
        addText("Training tools only — this app does not modify CODM or automate aiming.", 13, Color.LTGRAY)
        addText("FEATURE SWITCHES", 18, Color.WHITE, true)

        addSwitch("Recoil-Control Training", "recoil", true,
            "Turns guided recoil drills and practice tips on/off.")
        addSwitch("Sensitivity Assistant", "sensitivity", true,
            "Turns sensitivity profile tools and manual recommendations on/off.")
        addSwitch("Aim-Training Coach", "aim", true,
            "Turns target-tracking drills and practice sessions on/off.")
        addSwitch("Aim-Assist Settings Guide", "aim_guide", true,
            "Shows guidance for supported in-game settings; does not force game settings.")
        addSwitch("Performance Tracker", "tracker", true,
            "Turns local practice-session logging on/off.")

        val master = Switch(this).apply {
            text = "MASTER: Enable training modules"
            textSize = 16f
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("master", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("master", checked).apply()
                listOf("recoil", "sensitivity", "aim", "aim_guide", "tracker").forEach {
                    prefs.edit().putBoolean(it, checked).apply()
                }
                buildUi()
            }
        }
        root.addView(master, matchWrap())
        addText("PRACTICE SESSION", 18, Color.WHITE, true)
        addText("Record results from a practice round. Accuracy is calculated from the numbers you enter.", 13, Color.LTGRAY)

        val attempts = EditText(this).apply {
            hint = "Targets attempted"
            inputType = 2
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        }
        val hits = EditText(this).apply {
            hint = "Targets hit"
            inputType = 2
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        }
        root.addView(attempts, matchWrap())
        root.addView(hits, matchWrap())
        val save = Button(this).apply {
            text = "SAVE PRACTICE RESULT"
            setOnClickListener {
                if (!prefs.getBoolean("master", true) || !prefs.getBoolean("tracker", true)) {
                    toast("Turn on the master switch and Performance Tracker first.")
                    return@setOnClickListener
                }
                val a = attempts.text.toString().toIntOrNull()
                val h = hits.text.toString().toIntOrNull()
                if (a == null || h == null || a <= 0 || h < 0 || h > a) {
                    toast("Enter valid numbers: hits must be between 0 and attempts.")
                    return@setOnClickListener
                }
                val pct = h * 100.0 / a
                val old = prefs.getString("history", "") ?: ""
                val entry = "${System.currentTimeMillis()} | $h/$a | ${"%.1f".format(pct)}%"
                prefs.edit().putString("history", (old + entry + "\n").takeLast(5000)).apply()
                status.text = "Saved result: ${"%.1f".format(pct)}% accuracy"
                toast(status.text.toString())
            }
        }
        root.addView(save, matchWrap())
        status = TextView(this).apply {
            text = "No new result yet."
            textSize = 14f
            setTextColor(Color.rgb(90, 220, 160))
            setPadding(0, 10, 0, 10)
        }
        root.addView(status, matchWrap())
        root.addView(Button(this).apply {
            text = "VIEW PRACTICE HISTORY"
            setOnClickListener {
                val history = prefs.getString("history", "")?.ifBlank { "No sessions saved yet." } ?: "No sessions saved yet."
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle("Practice History").setMessage(history)
                    .setPositiveButton("Close", null).show()
            }
        }, matchWrap())
        addText("Note: ON/OFF switches control only this app's training features. They do not activate aimbots, guarantee zero recoil, or change CODM's protected game mechanics.", 12, Color.LTGRAY)
    }

    private fun addSwitch(label: String, key: String, default: Boolean, description: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 8, 0, 8)
        }
        val sw = Switch(this).apply {
            text = label
            textSize = 16f
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean(key, default) && prefs.getBoolean("master", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
            }
        }
        box.addView(sw, matchWrap())
        box.addView(TextView(this).apply {
            text = description
            textSize = 12f
            setTextColor(Color.LTGRAY)
        }, matchWrap())
        root.addView(box, matchWrap())
    }

    private fun addText(value: String, size: Int, color: Int, bold: Boolean = false) {
        root.addView(TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 8)
        }, matchWrap())
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 6 }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
